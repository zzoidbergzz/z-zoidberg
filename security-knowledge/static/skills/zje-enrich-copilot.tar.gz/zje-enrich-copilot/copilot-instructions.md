# z.je Enrichment — GitHub Copilot Skill v1.0.0

## Overview

z.je threat intelligence enrichment for GitHub Copilot. Query IOCs, enrich with 11 providers, run analysis with provenance tracking, post results back to z.je.

## Setup

Copy this file as `.github/copilot-instructions.md` in your repository.

### Environment
```
ZJE_API_URL=https://z.je
ZJE_API_KEY=<your-key>
```
Get API key at https://z.je/settings → API Keys.

## API Reference

### Authentication
All requests: `X-API-Key` header. Base URL: `https://z.je`. Swagger: https://z.je/docs

### Entity Kinds
`vulnerability actor malware product ip_address domain hash url email cve cwe organization asn indicator tool campaign attack_pattern course_of_action report other`

### Key Endpoints

| Action | Method | Endpoint |
|--------|--------|----------|
| Search | GET | `/api/v1/search/?q={query}&limit={n}` |
| Lookup IOC | POST | `/api/v1/mcp/call` body: `{"tool":"lookup_ioc","args":{"query":"1.2.3.4"}}` |
| Enrich (SSE) | GET | `/api/v1/enrich/{kind}/{value}/stream?providers=vt,shodan` |
| Force refresh | POST | `/api/v1/enrich/{kind}/{value}/refresh` |
| Get entity | GET | `/api/v1/entities/{id}` |
| Relationships | GET | `/api/v1/entities/{id}/relationships?limit=500` |
| List entities | GET | `/api/v1/entities/?kind={kind}&limit=200&offset=0` |
| Create entity | POST | `/api/v1/entities/` body: `{"name":"...","kind":"..."}` |
| Create claim | POST | `/api/v1/claims/` — see Claim Schema |
| Create evidence | POST | `/api/v1/evidence/` — see Evidence Schema |
| CVE lookup | POST | `/api/v1/mcp/call` body: `{"tool":"lookup_cve","args":{"cve_id":"CVE-2024-3094"}}` |
| Batch enrich | POST | `/api/v1/batch/enrich` body: `{"indicators":[{"kind":"ip_address","value":"1.2.3.4"}],"delay_seconds":1.0}` |
| Submit analysis | POST | `/api/v1/analysis/submit` — structured LLM findings |
| LLM summary | GET | `/api/v1/analysis/llm-summary/{entity_id}` |
| EUVD search | GET | `/api/v1/euvd/search?q=&vendor=&product=&min_score=&min_epss=` |
| STIX export | POST | `/api/v1/mcp/call` body: `{"tool":"export_stix_bundle","args":{}}` |
| BYOK keys | PUT | `/api/v1/auth/provider-keys/{provider}` body: `{"api_key":"..."}` |

### MCP Tools (60+)
Call via `POST /api/v1/mcp/call` with `{"tool": "...", "args": {...}}`:

**Core**: `lookup_ioc`, `enrich_entity`, `lookup_cve`, `search_knowledge`, `list_entities`, `get_entity`, `create_entity`, `create_claim`, `create_evidence`, `export_stix_bundle`, `ingest_url`, `unified_search`, `searxng_search`

**MITRE ATT&CK (30+)**: `get_all_techniques`, `get_all_groups`, `get_all_software`, `get_all_campaigns`, `get_techniques_used_by_group`, `get_groups_using_technique`, `get_techniques_by_tactic`, `get_techniques_by_platform`, `get_mitigations_mitigating_technique`, `get_procedure_examples_by_technique`

**Other**: `ask_question`, `cve_lookup`, `exploit_search`, `corpus_search`, `translate_text`, `necti_collect`

## Claim Schema — LLM Analysis

When posting analysis, ALWAYS follow provenance rules:

```json
POST /api/v1/claims/
{
  "statement": "Description of finding",
  "claim_type": "llm_analysis",
  "confidence": 0.4,
  "entity_id": "uuid",
  "source_kind": "llm_analysis",
  "llm_model": "copilot",
  "subject": "EntityA",
  "predicate": "attributed_to",
  "object": "EntityB"
}
```

## Evidence Schema

```json
POST /api/v1/evidence/
{
  "title": "LLM Analysis: copilot on APT29 infrastructure",
  "content": "[UNVERIFIED] Analysis with unconfirmed claims tagged...",
  "source_url": "llm://copilot/abc123def",
  "entity_id": "uuid",
  "claim_id": "uuid",
  "confidence": 0.4
}
```

## Analysis Submit (batch findings)

```json
POST /api/v1/analysis/submit
{
  "entity_id": "uuid",
  "findings": [{
    "statement": "Infrastructure overlaps with APT29 C2",
    "finding_type": "infrastructure_link",
    "confidence_raw": 0.8,
    "verification_status": "unverified",
    "evidence_text": "Shared SSL cert and hosting",
    "llm_model": "copilot"
  }],
  "source_kind": "llm_analysis",
  "llm_model": "copilot",
  "confidence_multiplier": 0.5
}
```

## Anti-Hallucination Protocol

**NEVER post LLM output as verified intelligence.**

1. LLM assertions about specific IOCs → MUST verify via enrichment providers first
2. LLM assertions about TTPs → MUST cross-reference MITRE ATT&CK
3. LLM assertions about CVEs → MUST verify via `lookup_cve`
4. Unverifiable claims → prefix evidence with `[UNVERIFIED]`
5. LLM-sourced IOCs → confidence 0.2 until verified

### Confidence Rules
| Source | claim_type | max confidence |
|--------|-----------|----------------|
| Enrichment provider | `enrichment` | 0.9 |
| OSINT feed | `osint` | 0.8 |
| **LLM analysis** | `llm_analysis` | **0.5** |
| Human analyst | `assessment` | 1.0 |

### Scoring
- LLM source: × 0.5 (hard cap 0.5)
- Stacked LLM: × 0.25
- MITRE cross-reference: +0.1 (cap 0.5)
- Provider confirmed → upgrade to `enrichment`
- OSINT found → upgrade to `osint`

## Enrichment Workflow

1. **Gather**: `search` → `lookup_ioc` → `enrich_stream` → `relationships` → MITRE tools
2. **Analyze**: correlate findings, identify links, map TTPs, score confidence
3. **Post**: `create_entity` → `create_claim` (type=llm_analysis, conf≤0.5) → `create_evidence` (model tag)
4. **Verify**: cross-check via providers, upgrade claim_type if confirmed

## BYOK Providers

`PUT /api/v1/auth/provider-keys/{provider}` with `{"api_key": "..."}`

Supported: virustotal, shodan, crowdstrike, greynoise, ipinfo, abuseipdb, misp, opencti, recordedfuture, otx, malshare, anthropic

## Quick Examples

```bash
API="https://z.je"
KEY="your-key"

# Search
curl -s -H "X-API-Key: $KEY" "$API/api/v1/search/?q=APT29&limit=5"

# Enrich IOC
curl -s -H "X-API-Key: $KEY" "$API/api/v1/enrich/ip_address/1.2.3.4/stream?providers=vt,shodan"

# CVE lookup
curl -s -H "X-API-Key: $KEY" -X POST "$API/api/v1/mcp/call" \
  -H "Content-Type: application/json" \
  -d '{"tool":"lookup_cve","args":{"cve_id":"CVE-2024-3094"}}'

# Post LLM analysis
curl -s -H "X-API-Key: $KEY" -X POST "$API/api/v1/analysis/submit" \
  -H "Content-Type: application/json" \
  -d '{"entity_id":"uuid","findings":[{"statement":"Attributed to APT29","finding_type":"ttp_attribution","confidence_raw":0.8,"verification_status":"unverified","evidence_text":"TTP overlap","llm_model":"copilot"}],"source_kind":"llm_analysis","llm_model":"copilot"}'
```
