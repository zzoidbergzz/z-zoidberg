---
name: zje-enrich
description: Enrich threat intelligence IOCs, CVEs, and entities via z.je API with BYOK provider keys and optional LLM analysis. Use when: looking up IOCs (IPs, domains, hashes, URLs, emails), enriching entities with threat intel providers, performing bulk IOC triage, researching CVEs or threat actors, running LLM-assisted analysis of threat data and posting results back to z.je, exporting STIX bundles, or querying MITRE ATT&CK knowledge. Triggers on: IOC enrichment, threat intel lookup, CVE research, bulk IOC processing, CTI analysis, z.je queries, indicator triage.
---

# z.je Enrichment Skill

Threat intelligence enrichment via z.je API. BYOK for providers + LLM analysis with provenance tracking.

## Configuration

```
ZJE_API_URL=https://z.je          # or self-hosted
ZJE_API_KEY=<your-key>            # required
```

Set `X-API-Key` header on all requests. Get a key at z.je/settings → API Keys.

## Entity Kinds

```
vulnerability actor malware product ip_address domain hash url email cve cwe
organization asn indicator tool campaign attack_pattern course_of_action report other
```

## Core Endpoints

| Action | Method | Endpoint | Notes |
|--------|--------|----------|-------|
| Search | GET | `/api/v1/search/?q={query}&limit={n}` | FTS across all entities, claims, corpus |
| Semantic search | POST | `/api/v1/search/semantic` | `{query, limit, kind}` — vector search |
| Unified search | MCP `unified_search` | `{query, limit, categories, enrich, db_only}` | Multi-source |
| EUVD search | GET | `/api/v1/euvd/search?q=&vendor=&product=&min_score=&min_epss=` | EU vuln DB |
| Lookup IOC | MCP `lookup_ioc` | `{query, force_repoll}` | Auto-detect IOC type |
| Enrich entity | MCP `enrich_entity` | `{entity_kind, entity_value, providers}` | All/specific providers |
| Enrich SSE | GET | `/api/v1/enrich/{kind}/{value}/stream?providers=vt,shodan` | Server-sent events |
| Force refresh | POST | `/api/v1/enrich/{kind}/{value}/refresh` | Bypass cache |
| Get entity | GET | `/api/v1/entities/{id}` | Full entity + relationships |
| Entity relationships | GET | `/api/v1/entities/{id}/relationships?limit=500` | Graph edges |
| List entities | GET | `/api/v1/entities/?kind={kind}&limit=200&offset=0` | Paginated |
| Create entity | POST `/api/v1/entities/` | `{name, kind}` | Returns entity with id |
| Create claim | POST `/api/v1/claims/` | See Claim Schema below | Attach intel to entity |
| Create evidence | POST `/api/v1/evidence/` | `{title, content, source_url, entity_id, confidence}` | Verify claims |
| CVE lookup | MCP `lookup_cve` / `cve_lookup` | `{cve_id}` | NVD + enrichment |
| IOC extract | POST `/api/v1/ingest/` | `{source_url, source_type}` | Async ingestion |
| STIX export | MCP `export_stix_bundle` | `{entity_ids, since}` | STIX 2.1 bundle |
| Graph | GET `/api/v1/graph/` | `?entity_id=&depth=` | vis-network JSON |
| Webhooks | CRUD `/api/v1/webhooks/` | Event-driven notifications | |
| Taxii 2.1 | GET `/taxii2/collections/{id}/objects/` | STIX/TAXII feed |
| Batch enrich | POST `/api/v1/batch/enrich` | {indicators, providers, delay_seconds} |
| Submit analysis | POST `/api/v1/analysis/submit` | LLM findings with provenance |
| LLM summary | GET `/api/v1/analysis/llm-summary/{entity_id}` | LLM claims stats |

## Claim Schema (critical for LLM analysis)

```
POST /api/v1/claims/
{
  "statement": "string",          # What is claimed
  "claim_type": "llm_analysis",   # USE THIS for LLM-generated intel
  "confidence": 0.4,              # 0.0-1.0 — MUST be ≤ 0.5 for LLM claims
  "subject": "entity_name",       # Optional: subject-predicate-object triple
  "predicate": "attributed_to",
  "object": "other_entity"
}
```

### Provenance Rules (mandatory)

| Source | claim_type | max confidence | Evidence required |
|--------|-----------|----------------|-------------------|
| Enrichment provider (VT, Shodan, etc.) | `enrichment` | 0.9 | Provider name + timestamp |
| OSINT feed | `osint` | 0.8 | Source URL |
| LLM analysis | `llm_analysis` | **0.5** | Model name + prompt hash + verify hint |
| Human analyst | `assessment` | 1.0 | Analyst ID |

**LLM claims MUST:**
- Use `claim_type: "llm_analysis"`
- Set confidence ≤ 0.5 (further reduced from raw LLM confidence by 0.5x)
- Include evidence with `source_url: "llm://{model_name}/{query_hash}"`
- Include `title` in evidence naming the LLM model used
- Flag unverifiable assertions in `content` with `[UNVERIFIED]` prefix

### Confidence Scoring

```
final_confidence = min(raw_confidence * source_multiplier, max_for_type)

source_multiplier:
  enrichment_provider = 1.0
  osint              = 0.9
  llm_analysis       = 0.5    ← hard cap at 0.5
  human              = 1.0
```

## Evidence Schema

```
POST /api/v1/evidence/
{
  "title": "LLM Analysis: GPT-4o on APT29 infrastructure",
  "content": "Analysis text with [UNVERIFIED] tags on unconfirmed claims...",
  "source_url": "llm://gpt-4o/abc123def",
  "entity_id": "uuid",
  "claim_id": "uuid",           # optional: attach to specific claim
  "confidence": 0.4
}
```

## BYOK Provider Keys

```
GET  /api/v1/auth/provider-keys/supported    # List supported providers
GET  /api/v1/auth/provider-keys              # List your stored keys
PUT  /api/v1/auth/provider-keys/{provider}   # Store key: {"api_key": "..."}
DELETE /api/v1/auth/provider-keys/{provider} # Remove key
```

Supported providers: `virustotal`, `shodan`, `crowdstrike`, `greynoise`, `ipinfo`, `abuseipdb`, `misp`, `opencti`, `nvd`, `recordedfuture`, `otx`, `malshare`

## Enrichment Providers (11)

| Provider | IOC Types | BYOK |
|----------|-----------|------|
| VirusTotal | hash, ip, domain, url | ✅ |
| Shodan | ip | ✅ |
| CrowdStrike | ip, domain, hash | ✅ |
| GreyNoise | ip | ✅ |
| IPinfo | ip | ✅ |
| AbuseIPDB | ip | ✅ |
| BGP.he.net | ip, asn | Free |
| MISP | all | ✅ BYOK |
| OpenCTI | all | ✅ BYOK |
| NVD | cve | Free |
| MITRE ATT&CK | attack_pattern, group, software | Free |

## MITRE ATT&CK (30+ MCP tools)

Quick reference — see `references/analyst-prompts-v1.md` for full usage:

```
get_all_techniques, get_all_groups, get_all_software, get_all_campaigns
get_techniques_used_by_group, get_software_used_by_group
get_groups_using_technique, get_groups_using_software
get_techniques_by_tactic, get_techniques_by_platform
get_mitigations_mitigating_technique
get_procedure_examples_by_technique
```

## LLM Analysis Workflow

### Step 1: Gather Data
```
# Search existing knowledge
GET /api/v1/search/?q={target}&limit=20

# Enrich with providers
GET /api/v1/enrich/{kind}/{value}/stream?providers=vt,shodan,greynoise

# Get relationships
GET /api/v1/entities/{id}/relationships?limit=200
```

### Step 2: Analyze with LLM
The agent running this skill IS the LLM. Perform analysis:

1. Correlate enrichment results with existing knowledge
2. Identify new relationships, TTPs, infrastructure links
3. Cross-reference MITRE ATT&CK
4. Score confidence per finding

### Step 3: Post Results
For each finding:
1. Create/resolve entity via `POST /api/v1/entities/` or `lookup_ioc`
2. Create claims with `claim_type: "llm_analysis"`, confidence ≤ 0.5
3. Tag unverifiable claims with `[UNVERIFIED]` in evidence content
4. Create evidence with `source_url: "llm://{model_name}/{query_hash}"`

### Step 4: Verify (when possible)
- Cross-check LLM claims against enrichment providers
- If provider confirms → upgrade claim_type to `enrichment`, raise confidence
- If provider contradicts → flag claim with `[CONTRADICTED]` in evidence

## Batch & Analysis Endpoints

### Batch Enrichment
```
POST /api/v1/batch/enrich
{
  "indicators": [{"kind": "ip_address", "value": "1.2.3.4"}, ...],
  "providers": "vt,shodan",        // optional
  "delay_seconds": 1.0              // rate limit between requests
}
```
Max 50 indicators per batch. Returns per-indicator status.

### Submit LLM Analysis
```
POST /api/v1/analysis/submit
{
  "entity_id": "uuid",
  "findings": [{
    "statement": "Description",
    "finding_type": "infrastructure_link|ttp_attribution|temporal|victimology|detection",
    "confidence_raw": 0.8,
    "verification_status": "unverified|partially_verified|verified",
    "evidence_text": "Supporting analysis",
    "llm_model": "gpt-4o",
    "subject": "EntityA",        // optional
    "predicate": "communicates_with", // optional
    "object": "EntityB"          // optional
  }],
  "source_kind": "llm_analysis",
  "llm_model": "gpt-4o",
  "confidence_multiplier": 0.5   // default 0.5, can be lower for stacked LLM
}
```
Creates claims + evidence with proper provenance. Confidence auto-capped at 0.5 for `llm_analysis`.

### LLM Claims Summary
```
GET /api/v1/analysis/llm-summary/{entity_id}
→ {entity_id, total_llm_claims, avg_confidence, models_used, unverified_count}
```
Quick overview of LLM-sourced intelligence for an entity.

## Anti-Hallucination Protocol

**NEVER post LLM output as verified intelligence.** Rules:
- LLM assertions about specific IPs/domains/hashes → MUST be verified via enrichment providers before posting as `enrichment` type
- LLM assertions about TTP attribution → MUST cross-reference MITRE ATT&CK
- LLM assertions about CVE details → MUST verify via `lookup_cve`
- Generic analytical observations → OK as `llm_analysis` with confidence ≤ 0.4
- If LLM produces specific IOCs → verify via `lookup_ioc` before creating entities
- Any claim that cannot be verified → prefix evidence content with `[UNVERIFIED]`

## Quick Examples

```bash
API="https://z.je"
KEY="your-key"
H="X-API-Key: $KEY"

# Search + enrich an IP
curl -s -H "$H" "$API/api/v1/search/?q=1.2.3.4&limit=5"
curl -s -H "$H" "$API/api/v1/enrich/ip_address/1.2.3.4/stream?providers=vt,shodan,abuseipdb"

# Lookup CVE
curl -s -H "$H" -X POST "$API/api/v1/mcp/call" \
  -H "Content-Type: application/json" \
  -d '{"tool":"lookup_cve","args":{"cve_id":"CVE-2024-3094"}}'

# Create entity + LLM analysis claim
curl -s -H "$H" -X POST "$API/api/v1/entities/" \
  -H "Content-Type: application/json" \
  -d '{"name":"malware-name","kind":"malware"}'
# Then claim:
curl -s -H "$H" -X POST "$API/api/v1/claims/" \
  -H "Content-Type: application/json" \
  -d '{"statement":"Attributed to APT29 based on infrastructure overlap","claim_type":"llm_analysis","confidence":0.4}'
```
