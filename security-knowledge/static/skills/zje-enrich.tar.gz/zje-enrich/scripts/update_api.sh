#!/bin/bash
# z.je API updates for zje-enrich skill
# Adds: source_kind, llm_model to claims; claim_id,confidence to evidence; batch enrichment; analysis endpoint

set -e
REMOTE="z@z.je"
BASE="/home/z/z-zoidberg/security-knowledge"

echo "=== Updating ClaimCreate schema ==="
ssh "$REMOTE" "cd $BASE && python3 -c \"
import re, pathlib
f = pathlib.Path('app/routers/claims.py')
c = f.read_text()

# Update ClaimCreate - add entity_id, source_url, source_kind, llm_model
old = '''class ClaimCreate(BaseModel):
    statement: str
    claim_type: str = \\\"general\\\"
    confidence: float = 0.5
    subject: str | None = None
    predicate: str | None = None
    object: str | None = None'''

new = '''class ClaimCreate(BaseModel):
    statement: str
    claim_type: str = \\\"general\\\"
    confidence: float = 0.5
    subject: str | None = None
    predicate: str | None = None
    object: str | None = None
    entity_id: str | None = None
    source_url: str | None = None
    source_kind: str | None = None  # human|osint|enrichment|llm_analysis
    llm_model: str | None = None    # e.g. gpt-4o, claude-3.5 (for llm_analysis claims)'''

c = c.replace(old, new)

# Update ClaimOut - add source_kind, llm_model
old2 = '''class ClaimOut(BaseModel):
    id: uuid.UUID
    statement: str
    claim_type: str
    confidence: float
    tenant_id: uuid.UUID
    entity_id: uuid.UUID | None = None
    source_url: str | None = None
    model_config = {\\\"from_attributes\\\": True}'''

new2 = '''class ClaimOut(BaseModel):
    id: uuid.UUID
    statement: str
    claim_type: str
    confidence: float
    tenant_id: uuid.UUID
    entity_id: uuid.UUID | None = None
    source_url: str | None = None
    source_kind: str | None = None
    llm_model: str | None = None
    model_config = {\\\"from_attributes\\\": True}'''

c = c.replace(old2, new2)

f.write_text(c)
print('claims.py updated')
\""

echo "=== Updating create_claim endpoint ==="
ssh "$REMOTE" "cd $BASE && python3 -c \"
import pathlib
f = pathlib.Path('app/routers/claims.py')
c = f.read_text()

# Update the create_claim endpoint to pass new fields through to value JSONB
old = '''    value: dict[str, Any] = {\\\"assertion\\\": statement}
    if body.subject:
        value[\\\"subject\\\"] = body.subject
    if body.predicate:
        value[\\\"predicate\\\"] = body.predicate
    if body.object:
        value[\\\"object\\\"] = body.object
    claim = Claim(
        tenant_id=_tenant_id(auth),
        claim_type=body.claim_type,
        value=value,
        confidence=body.confidence,
    )
    db.add(claim)
    await db.flush()
    await db.refresh(claim)
    return {
        \\\"id\\\": claim.id,
        \\\"statement\\\": statement,
        \\\"claim_type\\\": claim.claim_type,
        \\\"confidence\\\": claim.confidence,
        \\\"tenant_id\\\": claim.tenant_id,
    }'''

new = '''    value: dict[str, Any] = {\\\"assertion\\\": statement}
    if body.subject:
        value[\\\"subject\\\"] = body.subject
    if body.predicate:
        value[\\\"predicate\\\"] = body.predicate
    if body.object:
        value[\\\"object\\\"] = body.object
    if body.source_url:
        value[\\\"source_url\\\"] = body.source_url
    if body.source_kind:
        value[\\\"source_kind\\\"] = body.source_kind
    if body.llm_model:
        value[\\\"llm_model\\\"] = body.llm_model
    entity_id_val = uuid.UUID(body.entity_id) if body.entity_id else None
    claim = Claim(
        tenant_id=_tenant_id(auth),
        entity_id=entity_id_val,
        claim_type=body.claim_type,
        value=value,
        confidence=body.confidence,
    )
    db.add(claim)
    await db.flush()
    await db.refresh(claim)
    # Build response with new fields
    resp = {
        \\\"id\\\": claim.id,
        \\\"statement\\\": statement,
        \\\"claim_type\\\": claim.claim_type,
        \\\"confidence\\\": claim.confidence,
        \\\"tenant_id\\\": claim.tenant_id,
        \\\"entity_id\\\": claim.entity_id,
        \\\"source_url\\\": body.source_url,
        \\\"source_kind\\\": body.source_kind,
        \\\"llm_model\\\": body.llm_model,
    }
    return resp'''

c = c.replace(old, new)
f.write_text(c)
print('create_claim endpoint updated')
\""

echo "=== Updating list_claims to return new fields ==="
ssh "$REMOTE" "cd $BASE && python3 -c \"
import pathlib
f = pathlib.Path('app/routers/claims.py')
c = f.read_text()

# Update the list claims response
old = '''            \\\"source_url\\\": (claim.value or {}).get(\\\"source_url\\\") if isinstance(claim.value, dict) else None,
        }
        for claim in claims
    ]'''

new = '''            \\\"source_url\\\": (claim.value or {}).get(\\\"source_url\\\") if isinstance(claim.value, dict) else None,
            \\\"source_kind\\\": (claim.value or {}).get(\\\"source_kind\\\") if isinstance(claim.value, dict) else None,
            \\\"llm_model\\\": (claim.value or {}).get(\\\"llm_model\\\") if isinstance(claim.value, dict) else None,
        }
        for claim in claims
    ]'''

c = c.replace(old, new)
f.write_text(c)
print('list_claims updated')
\""

echo "=== Updating EvidenceCreate schema ==="
ssh "$REMOTE" "cd $BASE && python3 -c \"
import pathlib
f = pathlib.Path('app/routers/evidence.py')
c = f.read_text()

old = '''class EvidenceCreate(BaseModel):
    title: str
    content: str
    source_url: str | None = None
    entity_id: uuid.UUID | None = None'''

new = '''class EvidenceCreate(BaseModel):
    title: str
    content: str
    source_url: str | None = None
    entity_id: uuid.UUID | None = None
    claim_id: uuid.UUID | None = None
    confidence: float = 1.0'''

c = c.replace(old, new)
f.write_text(c)
print('evidence.py updated')
\""

echo "=== Creating batch enrichment endpoint ==="
ssh "$REMOTE" "cat > $BASE/app/routers/batch.py << 'PYEOF'
import asyncio
import uuid
from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from app.auth.dependencies import AuthContext, require_read, require_write
from app.routers.enrich import _stream_enrich
from app.database import get_db

router = APIRouter(prefix=\"/batch\", tags=[\"enrich\"])


class BatchEnrichRequest(BaseModel):
    indicators: list[dict]  # [{\"kind\": \"ip_address\", \"value\": \"1.2.3.4\"}, ...]
    providers: str | None = None
    delay_seconds: float = 1.0


class BatchEnrichResult(BaseModel):
    kind: str
    value: str
    status: str  # ok | error
    entity_id: uuid.UUID | None = None
    providers_completed: int = 0
    error: str | None = None


class BatchEnrichResponse(BaseModel):
    total: int
    results: list[BatchEnrichResult]


@router.post(\"/enrich\", response_model=BatchEnrichResponse)
async def batch_enrich(
    body: BatchEnrichRequest,
    auth: AuthContext | dict = Depends(require_write),
):
    \"\"\"Batch enrich multiple indicators. Rate-limited between requests.

    Each indicator: {\"kind\": \"ip_address\", \"value\": \"1.2.3.4\"}
    Max 50 indicators per batch.
    \"\"\"
    indicators = body.indicators[:50]  # hard cap
    results = []
    for ioc in indicators:
        kind = ioc.get(\"kind\", \"indicator\")
        value = ioc.get(\"value\", \"\")
        if not value:
            results.append(BatchEnrichResult(kind=kind, value=\"\", status=\"error\", error=\"missing value\"))
            continue
        try:
            entity, provider_results = await _stream_enrich(
                kind=kind, value=value,
                providers=body.providers,
                tenant_id=str(auth.tenant_id) if hasattr(auth, \"tenant_id\") else str(auth[\"tenant_id\"]),
            )
            results.append(BatchEnrichResult(
                kind=kind, value=value, status=\"ok\",
                entity_id=entity.id if entity else None,
                providers_completed=len(provider_results),
            ))
        except Exception as e:
            results.append(BatchEnrichResult(
                kind=kind, value=value, status=\"error\", error=str(e),
            ))
        if body.delay_seconds > 0:
            await asyncio.sleep(body.delay_seconds)
    return BatchEnrichResponse(total=len(indicators), results=results)
PYEOF
echo 'batch.py created'"

echo "=== Creating analysis endpoint ==="
ssh "$REMOTE" "cat > $BASE/app/routers/analysis.py << 'PYEOF'
import uuid
from datetime import datetime
from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.dependencies import AuthContext, require_read, require_write
from app.database import get_db
from app.models.claims import Claim
from app.models.evidence import Evidence
from app.models.entities import Entity

router = APIRouter(prefix=\"/analysis\", tags=[\"analysis\"])


class AnalysisRequest(BaseModel):
    \"\"\"Submit structured LLM analysis with provenance tracking.\"\"\"
    entity_id: uuid.UUID
    findings: list[dict]  # Each: {statement, finding_type, confidence_raw, verification_status, evidence_text, llm_model}
    source_kind: str = \"llm_analysis\"
    llm_model: str = \"unknown\"
    # Confidence multiplier for LLM (always 0.5, can be lower for stacked LLM)
    confidence_multiplier: float = 0.5


class AnalysisResponse(BaseModel):
    entity_id: uuid.UUID
    claims_created: int
    evidence_created: int
    claim_ids: list[uuid.UUID] = []
    errors: list[str] = []


@router.post(\"/submit\", response_model=AnalysisResponse)
async def submit_analysis(
    body: AnalysisRequest,
    db: AsyncSession = Depends(get_db),
    auth: AuthContext = Depends(require_write),
):
    \"\"\"Submit LLM analysis findings as claims + evidence with provenance.

    Each finding becomes:
    - A claim with claim_type=source_kind, confidence=raw*multiplier (capped at 0.5 for llm_analysis)
    - An evidence record with LLM model tag and source_url=llm://model/hash
    \"\"\"
    tenant_id = str(auth.tenant_id) if hasattr(auth, \"tenant_id\") else str(auth[\"tenant_id\"])
    claims_created = 0
    evidence_created = 0
    claim_ids = []
    errors = []
    cap = 0.5 if body.source_kind == \"llm_analysis\" else 1.0

    for finding in body.findings:
        try:
            raw_conf = finding.get(\"confidence_raw\", 0.5)
            adjusted = min(raw_conf * body.confidence_multiplier, cap)

            stmt = finding.get(\"statement\", \"\")
            finding_type = finding.get(\"finding_type\", \"general\")
            llm_model = finding.get(\"llm_model\", body.llm_model)
            evidence_text = finding.get(\"evidence_text\", \"\")
            verification = finding.get(\"verification_status\", \"unverified\")
            subject = finding.get(\"subject\")
            predicate = finding.get(\"predicate\")
            object_ = finding.get(\"object\")

            # Build value JSONB
            value = {\"assertion\": stmt, \"source_kind\": body.source_kind, \"llm_model\": llm_model}
            if finding_type:
                value[\"finding_type\"] = finding_type
            if verification:
                value[\"verification_status\"] = verification
            if subject:
                value[\"subject\"] = subject
            if predicate:
                value[\"predicate\"] = predicate
            if object_:
                value[\"object\"] = object_

            # Create claim
            claim = Claim(
                tenant_id=tenant_id,
                entity_id=body.entity_id,
                claim_type=body.source_kind,
                value=value,
                confidence=adjusted,
            )
            db.add(claim)
            await db.flush()
            await db.refresh(claim)
            claim_ids.append(claim.id)
            claims_created += 1

            # Create evidence
            if evidence_text:
                import hashlib
                qhash = hashlib.sha256(stmt.encode()).hexdigest()[:12]
                ev = Evidence(
                    tenant_id=tenant_id,
                    entity_id=body.entity_id,
                    claim_id=claim.id,
                    title=f\"LLM Analysis: {llm_model}\",
                    content=f\"[{verification.upper()}] {evidence_text}\",
                    source_url=f\"llm://{llm_model}/{qhash}\",
                    confidence=adjusted,
                )
                db.add(ev)
                evidence_created += 1

        except Exception as e:
            errors.append(f\"Finding {finding.get('statement', '?')[:30]}: {e}\")

    return AnalysisResponse(
        entity_id=body.entity_id,
        claims_created=claims_created,
        evidence_created=evidence_created,
        claim_ids=claim_ids,
        errors=errors,
    )


class LlmClaimsSummary(BaseModel):
    entity_id: uuid.UUID
    total_llm_claims: int
    avg_confidence: float
    models_used: list[str]
    unverified_count: int


@router.get(\"/llm-summary/{entity_id}\", response_model=LlmClaimsSummary)
async def llm_claims_summary(
    entity_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    auth: AuthContext = Depends(require_read),
):
    \"\"\"Summary of LLM-sourced claims for an entity.\"\"\"
    tenant_id = str(auth.tenant_id) if hasattr(auth, \"tenant_id\") else str(auth[\"tenant_id\"])
    result = await db.execute(
        select(Claim)
        .where(Claim.entity_id == entity_id, Claim.tenant_id == tenant_id, Claim.claim_type == \"llm_analysis\")
    )
    claims = result.scalars().all()
    models = set()
    unverified = 0
    total_conf = 0.0
    for c in claims:
        v = c.value if isinstance(c.value, dict) else {}
        m = v.get(\"llm_model\", \"unknown\")
        if m:
            models.add(m)
        vs = v.get(\"verification_status\", \"\")
        if vs == \"unverified\":
            unverified += 1
        total_conf += c.confidence
    return LlmClaimsSummary(
        entity_id=entity_id,
        total_llm_claims=len(claims),
        avg_confidence=total_conf / len(claims) if claims else 0.0,
        models_used=sorted(models),
        unverified_count=unverified,
    )
PYEOF
echo 'analysis.py created'"

echo "=== Registering new routers in main.py ==="
ssh "$REMOTE" "cd $BASE && python3 -c \"
import pathlib
f = pathlib.Path('app/main.py')
c = f.read_text()

# Add imports for new routers
if 'from app.routers.batch' not in c:
    c = c.replace(
        'from app.routers import',
        'from app.routers import batch, analysis,'
    ) if 'from app.routers import' in c else c

# Add router registrations
if 'batch.router' not in c:
    # Find the last app.include_router line and add after it
    lines = c.split('\\n')
    last_include = -1
    for i, line in enumerate(lines):
        if 'app.include_router' in line:
            last_include = i
    if last_include >= 0:
        lines.insert(last_include + 1, 'app.include_router(batch.router, prefix=\"/api/v1\")')
        lines.insert(last_include + 2, 'app.include_router(analysis.router, prefix=\"/api/v1\")')
    c = '\\n'.join(lines)

f.write_text(c)
print('main.py updated')
\""

echo "=== Restarting z.je ==="
ssh "$REMOTE" "cd $BASE && pkill -f 'uvicorn app.main' || true && sleep 2 && nohup python3 -m uvicorn app.main:app --host 0.0.0.0 --port 8010 --workers 2 > /tmp/zje.log 2>&1 &"
sleep 5
echo "=== Testing new endpoints ==="
API="https://z.je"
KEY="YxjXShQyv8L_-X_1Qb6DDSF9JvPXGer5_yTztqgvCAQ"
echo "--- Health ---"
curl -s "$API/health" | python3 -m json.tool 2>/dev/null | head -5
echo "--- Analysis submit (should 422 on bad input, 200 on good) ---"
echo "Done. API updated with: source_kind, llm_model on claims; claim_id, confidence on evidence; /api/v1/batch/enrich; /api/v1/analysis/submit; /api/v1/analysis/llm-summary/{entity_id}"
