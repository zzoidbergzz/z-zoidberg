#!/usr/bin/env python3
"""Update z.je settings.html to add skill download section + provider keys"""
import pathlib
import sys

settings = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else pathlib.Path("templates/settings.html")
c = settings.read_text()

# Add skill download section before the Session section
skill_section = """  <section class="card">
    <h2>🦞 OpenClaw Skill</h2>
    <p class="muted">
      Install the <strong>zje-enrich</strong> skill for OpenClaw agents. Enables IOC enrichment,
      threat intel lookup, LLM-assisted analysis, and auto-posting results back to z.je
      — all from your agent console.
    </p>
    <details style="margin-top:0.6rem">
      <summary><strong>Install instructions</strong></summary>
      <pre style="background:var(--surface);padding:1rem;border-radius:6px;margin-top:0.4rem;overflow-x:auto;font-size:0.85rem"># Install from ClawHub
openclaw skill install zje-enrich

# Or manual
mkdir -p ~/.openclaw/skills/zje-enrich
# Then copy skill files into that directory

# Configure
export ZJE_API_URL=https://z.je
export ZJE_API_KEY=your-key-from-above

# Verify
python ~/.openclaw/skills/zje-enrich/scripts/zje_client.py search "APT29"</pre>
    </details>
    <p style="margin-top:0.6rem">
      <a href="/static/skills/zje-enrich.tar.gz" class="button" download>⬇ Download skill package</a>
      <span class="muted" style="margin-left:0.5rem">v1.0.0</span>
    </p>
  </section>

"""

c = c.replace('  <section class="card">\n    <h2>Session</h2>', skill_section + '  <section class="card">\n    <h2>Session</h2>')

# Add OTX, misp, opencti, recordedfuture, malshare to supported providers
old_providers = 'const SUPPORTED = ["virustotal","greynoise","ipinfo","shodan","abuseipdb","urlscan","anthropic"];'
new_providers = 'const SUPPORTED = ["virustotal","greynoise","ipinfo","shodan","abuseipdb","urlscan","anthropic","otx","misp","opencti","recordedfuture","malshare"];'
c = c.replace(old_providers, new_providers)

settings.write_text(c)
print("settings.html updated")
