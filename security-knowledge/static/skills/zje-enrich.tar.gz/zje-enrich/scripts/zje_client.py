#!/usr/bin/env python3
"""z.je enrichment client — CLI + library for zje-enrich skill.

Usage:
  # Single IOC lookup + enrich
  python zje_client.py lookup 1.2.3.4

  # Search knowledge base
  python zje_client.py search "APT29"

  # Enrich an entity
  python zje_client.py enrich ip_address 1.2.3.4 --providers vt,shodan

  # CVE lookup
  python zje_client.py cve CVE-2024-3094

  # Batch enrich from file (one IOC per line)
  python zje_client.py batch iocs.txt --delay 1.0

  # Post LLM analysis
  python zje_client.py post-analysis --entity-id UUID --statement "..." --model gpt-4o --confidence 0.4

  # STIX export
  python zje_client.py stix --entity-ids UUID1,UUID2
"""

import argparse
import json
import os
import sys
import time
import hashlib
from pathlib import Path

try:
    import httpx
except ImportError:
    print("pip install httpx") or sys.exit(1)


class ZjeClient:
    """Thin async client for z.je API."""

    def __init__(self, base_url: str | None = None, api_key: str | None = None):
        self.base_url = (base_url or os.getenv("ZJE_API_URL", "https://z.je")).rstrip("/")
        self.api_key = api_key or os.getenv("ZJE_API_KEY", "")
        if not self.api_key:
            raise ValueError("ZJE_API_KEY required (env var or constructor)")

    def _headers(self) -> dict:
        return {"X-API-Key": self.api_key, "Content-Type": "application/json"}

    # --- Search ---

    def search(self, query: str, limit: int = 20) -> list:
        r = httpx.get(
            f"{self.base_url}/api/v1/search/",
            params={"q": query, "limit": limit},
            headers=self._headers(),
            timeout=15,
        )
        r.raise_for_status()
        return r.json()

    # --- Entities ---

    def list_entities(self, kind: str | None = None, limit: int = 50, offset: int = 0) -> list:
        params = {"limit": limit, "offset": offset}
        if kind:
            params["kind"] = kind
        r = httpx.get(f"{self.base_url}/api/v1/entities/", params=params, headers=self._headers(), timeout=15)
        r.raise_for_status()
        return r.json()

    def get_entity(self, entity_id: str) -> dict:
        r = httpx.get(f"{self.base_url}/api/v1/entities/{entity_id}", headers=self._headers(), timeout=15)
        r.raise_for_status()
        return r.json()

    def create_entity(self, name: str, kind: str) -> dict:
        r = httpx.post(
            f"{self.base_url}/api/v1/entities/",
            json={"name": name, "kind": kind},
            headers=self._headers(),
            timeout=15,
        )
        r.raise_for_status()
        return r.json()

    def get_relationships(self, entity_id: str, limit: int = 200) -> list:
        r = httpx.get(
            f"{self.base_url}/api/v1/entities/{entity_id}/relationships",
            params={"limit": limit},
            headers=self._headers(),
            timeout=15,
        )
        r.raise_for_status()
        return r.json()

    # --- Enrichment ---

    def enrich_entity(self, entity_id: str) -> dict:
        r = httpx.post(f"{self.base_url}/api/v1/enrich/{entity_id}", headers=self._headers(), timeout=60)
        r.raise_for_status()
        return r.json()

    def enrich_stream(self, kind: str, value: str, providers: str | None = None) -> list:
        """SSE enrichment — collects all provider results."""
        params = {}
        if providers:
            params["providers"] = providers
        results = []
        with httpx.stream(
            "GET",
            f"{self.base_url}/api/v1/enrich/{kind}/{value}/stream",
            params=params,
            headers={"X-API-Key": self.api_key},
            timeout=120,
        ) as resp:
            for line in resp.iter_lines():
                if line.startswith("data: "):
                    try:
                        results.append(json.loads(line[6:]))
                    except json.JSONDecodeError:
                        pass
        return results

    def enrich_refresh(self, kind: str, value: str) -> dict:
        r = httpx.post(f"{self.base_url}/api/v1/enrich/{kind}/{value}/refresh", headers=self._headers(), timeout=60)
        r.raise_for_status()
        return r.json()

    # --- Claims ---

    def create_claim(self, statement: str, claim_type: str, confidence: float,
                     entity_id: str | None = None,
                     subject: str | None = None, predicate: str | None = None, object_: str | None = None) -> dict:
        body = {"statement": statement, "claim_type": claim_type, "confidence": confidence}
        if entity_id:
            body["entity_id"] = entity_id
        if subject:
            body["subject"] = subject
        if predicate:
            body["predicate"] = predicate
        if object_:
            body["object"] = object_
        r = httpx.post(f"{self.base_url}/api/v1/claims/", json=body, headers=self._headers(), timeout=15)
        r.raise_for_status()
        return r.json()

    def create_llm_claim(self, statement: str, entity_id: str, llm_model: str,
                         raw_confidence: float = 0.8, **kwargs) -> dict:
        """Create an LLM-sourced claim with provenance rules applied."""
        adjusted = min(raw_confidence * 0.5, 0.5)  # Hard cap at 0.5
        claim = self.create_claim(
            statement=statement,
            claim_type="llm_analysis",
            confidence=adjusted,
            entity_id=entity_id,
            **kwargs,
        )
        # Create evidence with LLM provenance
        query_hash = hashlib.sha256(statement.encode()).hexdigest()[:12]
        self.create_evidence(
            title=f"LLM Analysis: {llm_model}",
            content=f"[LLM: {llm_model}] {statement}",
            source_url=f"llm://{llm_model}/{query_hash}",
            entity_id=entity_id,
            claim_id=claim.get("id"),
            confidence=adjusted,
        )
        return claim

    # --- Evidence ---

    def create_evidence(self, title: str, content: str, source_url: str = "",
                        entity_id: str | None = None, claim_id: str | None = None,
                        confidence: float = 0.5) -> dict:
        body = {"title": title, "content": content, "source_url": source_url, "confidence": confidence}
        if entity_id:
            body["entity_id"] = entity_id
        if claim_id:
            body["claim_id"] = claim_id
        r = httpx.post(f"{self.base_url}/api/v1/evidence/", json=body, headers=self._headers(), timeout=15)
        r.raise_for_status()
        return r.json()

    # --- MCP ---

    def mcp_call(self, tool: str, args: dict) -> dict:
        r = httpx.post(
            f"{self.base_url}/api/v1/mcp/call",
            json={"tool": tool, "args": args},
            headers=self._headers(),
            timeout=60,
        )
        r.raise_for_status()
        return r.json()

    def lookup_ioc(self, query: str, force_repoll: bool = False) -> dict:
        return self.mcp_call("lookup_ioc", {"query": query, "force_repoll": force_repoll})

    def lookup_cve(self, cve_id: str) -> dict:
        return self.mcp_call("lookup_cve", {"cve_id": cve_id})

    def search_knowledge(self, query: str, limit: int = 20) -> dict:
        return self.mcp_call("search_knowledge", {"query": query, "limit": limit})

    # --- EUVD ---

    def euvd_search(self, q: str = "", vendor: str = "", product: str = "",
                    min_score: float | None = None, min_epss: float | None = None) -> dict:
        params = {}
        if q:
            params["q"] = q
        if vendor:
            params["vendor"] = vendor
        if product:
            params["product"] = product
        if min_score is not None:
            params["min_score"] = min_score
        if min_epss is not None:
            params["min_epss"] = min_epss
        r = httpx.get(f"{self.base_url}/api/v1/euvd/search", params=params, headers=self._headers(), timeout=15)
        r.raise_for_status()
        return r.json()

    # --- STIX ---

    def export_stix(self, entity_ids: list[str] | None = None, since: str | None = None) -> dict:
        args = {}
        if entity_ids:
            args["entity_ids"] = entity_ids
        if since:
            args["since"] = since
        return self.mcp_call("export_stix_bundle", args)

    # --- BYOK ---

    def list_provider_keys(self) -> list:
        r = httpx.get(f"{self.base_url}/api/v1/auth/provider-keys", headers=self._headers(), timeout=10)
        r.raise_for_status()
        return r.json()

    def set_provider_key(self, provider: str, api_key: str) -> dict:
        r = httpx.put(
            f"{self.base_url}/api/v1/auth/provider-keys/{provider}",
            json={"api_key": api_key},
            headers=self._headers(),
            timeout=10,
        )
        r.raise_for_status()
        return r.json()


def _format_results(data, mode: str = "table"):
    if isinstance(data, list):
        for item in data:
            print(json.dumps(item, indent=2) if mode == "json" else _short(item))
    else:
        print(json.dumps(data, indent=2) if mode == "json" else _short(data))


def _short(d: dict) -> str:
    name = d.get("name") or d.get("canonical_name") or d.get("statement") or d.get("title") or d.get("id", "?")
    kind = d.get("kind", "")
    conf = d.get("confidence", "")
    score = d.get("score", "")
    parts = [str(name)[:60]]
    if kind:
        parts.append(f"[{kind}]")
    if conf:
        parts.append(f"conf={conf:.2f}" if isinstance(conf, float) else f"conf={conf}")
    if score:
        parts.append(f"score={score:.2f}" if isinstance(score, float) else f"score={score}")
    return " ".join(parts)


def main():
    p = argparse.ArgumentParser(description="z.je enrichment client")
    p.add_argument("--url", default=os.getenv("ZJE_API_URL", "https://zje-api.je"), help="API base URL")
    p.add_argument("--key", default=os.getenv("ZJE_API_KEY", ""), help="API key")
    p.add_argument("--json", action="store_true", help="Raw JSON output")

    sub = p.add_subparsers(dest="cmd")

    # search
    s = sub.add_parser("search")
    s.add_argument("query")
    s.add_argument("--limit", type=int, default=20)

    # lookup
    s = sub.add_parser("lookup")
    s.add_argument("query")

    # enrich
    s = sub.add_parser("enrich")
    s.add_argument("kind")
    s.add_argument("value")
    s.add_argument("--providers")

    # cve
    s = sub.add_parser("cve")
    s.add_argument("cve_id")

    # batch
    s = sub.add_parser("batch")
    s.add_argument("file", help="File with one IOC per line")
    s.add_argument("--delay", type=float, default=1.0, help="Delay between enrichments (seconds)")

    # post-analysis
    s = sub.add_parser("post-analysis")
    s.add_argument("--entity-id", required=True)
    s.add_argument("--statement", required=True)
    s.add_argument("--model", required=True, help="LLM model name (e.g. gpt-4o)")
    s.add_argument("--confidence", type=float, default=0.4)
    s.add_argument("--subject")
    s.add_argument("--predicate")
    s.add_argument("--object")

    # stix
    s = sub.add_parser("stix")
    s.add_argument("--entity-ids", help="Comma-separated UUIDs")
    s.add_argument("--since", help="ISO timestamp")

    # euvd
    s = sub.add_parser("euvd")
    s.add_argument("--q", default="")
    s.add_argument("--vendor", default="")
    s.add_argument("--product", default="")
    s.add_argument("--min-score", type=float)
    s.add_argument("--min-epss", type=float)

    args = p.parse_args()
    if not args.cmd:
        p.print_help()
        return

    client = ZjeClient(base_url=args.url, api_key=args.key)
    mode = "json" if args.json else "table"

    if args.cmd == "search":
        _format_results(client.search(args.query, args.limit), mode)

    elif args.cmd == "lookup":
        _format_results(client.lookup_ioc(args.query), mode)

    elif args.cmd == "enrich":
        _format_results(client.enrich_stream(args.kind, args.value, args.providers), mode)

    elif args.cmd == "cve":
        _format_results(client.lookup_cve(args.cve_id), mode)

    elif args.cmd == "batch":
        iocs = Path(args.file).read_text().strip().splitlines()
        for ioc in iocs:
            ioc = ioc.strip()
            if not ioc or ioc.startswith("#"):
                continue
            print(f"→ {ioc}")
            try:
                result = client.lookup_ioc(ioc)
                _format_results(result, mode)
            except Exception as e:
                print(f"  ERROR: {e}")
            time.sleep(args.delay)

    elif args.cmd == "post-analysis":
        kwargs = {}
        if args.subject:
            kwargs["subject"] = args.subject
        if args.predicate:
            kwargs["predicate"] = args.predicate
        if args.object:
            kwargs["object_"] = args.object
        result = client.create_llm_claim(
            statement=args.statement,
            entity_id=args.entity_id,
            llm_model=args.model,
            raw_confidence=args.confidence * 2,  # will be halved by create_llm_claim
            **kwargs,
        )
        _format_results(result, mode)

    elif args.cmd == "stix":
        ids = args.entity_ids.split(",") if args.entity_ids else None
        _format_results(client.export_stix(entity_ids=ids, since=args.since), mode)

    elif args.cmd == "euvd":
        _format_results(client.euvd_search(q=args.q, vendor=args.vendor, product=args.product,
                                            min_score=args.min_score, min_epss=args.min_epss), mode)


if __name__ == "__main__":
    main()
