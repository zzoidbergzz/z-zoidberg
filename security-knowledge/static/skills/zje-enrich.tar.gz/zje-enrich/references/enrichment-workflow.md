# z.je Enrichment Skill — LLM Analysis Workflow

## Overview

The enrichment workflow has 4 phases: Gather → Analyze → Post → Verify.

## Phase 1: Gather

### 1a. Search existing knowledge
```
GET /api/v1/search/?q={target}&limit=20
```
Check if entity already exists. Use existing entity_id if found.

### 1b. IOC Lookup (auto-detect type)
```
POST /api/v1/mcp/call  {"tool": "lookup_ioc", "args": {"query": "1.2.3.4"}}
```
Returns entity if found, or triggers creation + enrichment.

### 1c. Provider Enrichment (SSE)
```
GET /api/v1/enrich/{kind}/{value}/stream?providers=vt,shodan,greynoise,abuseipdb
```
Stream results as they arrive. Parse SSE events:
```
event: provider_result
data: {"provider": "virustotal", "status": "ok", "data": {...}}

event: done
data: {"providers_completed": 4, "entity_kind": "ip_address", "entity_value": "1.2.3.4"}
```

### 1d. Relationship traversal
```
GET /api/v1/entities/{id}/relationships?limit=200
```
Get connected entities for context.

### 1e. MITRE ATT&CK context
```
POST /api/v1/mcp/call  {"tool": "get_techniques_used_by_group", "args": {"group_id": "G0016"}}
POST /api/v1/mcp/call  {"tool": "get_groups_using_technique", "args": {"technique_id": "T1059"}}
```

## Phase 2: Analyze

The LLM (you) performs analysis on gathered data. Follow this structured approach:

### Analysis Framework
1. **Infrastructure correlation** — Link IPs, domains, certificates, ASNs
2. **TTP attribution** — Map observed behavior to MITRE ATT&CK
3. **Temporal analysis** — Timeline of activity from enrichment timestamps
4. **Infrastructure overlap** — Shared hosting, certs, registrars between entities
5. **Victimology** — Sector/geographic targeting patterns
6. **Detection opportunities** — YARA, SIGMA, CQL hunt suggestions

### Output Structure
For each finding, produce:
```json
{
  "finding": "Description of the finding",
  "finding_type": "infrastructure_link|ttp_attribution|temporal|victimology|detection",
  "entities_mentioned": ["entity_name1", "entity_name2"],
  "confidence_raw": 0.8,
  "confidence_adjusted": 0.4,  // raw * 0.5 for LLM
  "verification_status": "unverified|partially_verified|verified",
  "verification_method": "How to verify this finding",
  "sources_used": ["enrichment:virustotal", "knowledge:search", "mitre:attack"]
}
```

### Confidence Rules
- LLM reasoning from enrichment data → multiply by 0.5
- LLM reasoning from other LLM claims → multiply by 0.25 (stacking penalty)
- LLM producing specific IOCs → confidence 0.2 until verified
- Cross-referenced with MITRE → add +0.1 (capped at 0.5)
- Confirmed by enrichment provider → upgrade to `enrichment` claim_type

## Phase 3: Post

### 3a. Create/resolve entities
```bash
# Check if entity exists first
GET /api/v1/search/?q={name}&limit=5

# If not found, create
POST /api/v1/entities/  {"name": "NewEntity", "kind": "malware"}
```

### 3b. Create claims (LLM-sourced)
```bash
POST /api/v1/claims/  {
  "statement": "Finding description",
  "claim_type": "llm_analysis",
  "confidence": 0.4,  # ≤ 0.5 for LLM
  "subject": "EntityA",
  "predicate": "communicates_with",
  "object": "EntityB"
}
```

### 3c. Create evidence
```bash
POST /api/v1/evidence/  {
  "title": "LLM Analysis: {model} on {topic}",
  "content": "[UNVERIFIED] Detailed analysis text...",
  "source_url": "llm://{model_name}/{query_hash}",
  "entity_id": "uuid",
  "claim_id": "uuid",
  "confidence": 0.4
}
```

### 3d. Create relationships (via claims)
Use subject-predicate-object triples in claims to establish relationships.

## Phase 4: Verify

### Verification checklist per finding:
1. Can any enrichment provider confirm this? → Query them
2. Does MITRE ATT&CK reference this TTP? → `get_objects_by_name`
3. Does existing z.je knowledge support this? → Search
4. Can we find a public source (OSINT)? → `searxng_search`

### Upgrade path:
- `llm_analysis` + provider confirmation → `enrichment` (confidence up to 0.9)
- `llm_analysis` + OSINT source → `osint` (confidence up to 0.8)
- `llm_analysis` + MITRE reference → keep `llm_analysis` but add +0.1 (cap 0.5)
- `llm_analysis` + no verification → stays `llm_analysis`, confidence ≤ 0.4

## Batch Processing Pattern

For processing multiple IOCs efficiently:

```python
# Pseudocode
for ioc in ioc_list:
    # 1. Search existing
    existing = search(ioc)
    if existing:
        entity_id = existing[0].id
    else:
        # 2. Lookup/create
        result = lookup_ioc(ioc)
        entity_id = result.entity_id
    
    # 3. Enrich (with rate limiting)
    enrich(entity_id, providers=["vt", "shodan"])
    time.sleep(1)  # Rate limit
    
    # 4. Analyze
    findings = analyze(gathered_data)
    
    # 5. Post with provenance
    for finding in findings:
        create_claim(finding, claim_type="llm_analysis", confidence=finding.confidence_adjusted)
        create_evidence(finding, source_url=f"llm://{model}/{hash}")
```

## Error Handling

- `422` → Validate entity kind against allowed values
- `401` → Check API key, try token refresh
- `404` → Entity not found, create first
- `429` → Rate limited, exponential backoff
- `500` → Use MCP tools as fallback (REST endpoints have known issues)
- SSE stream interrupted → Use non-streaming `POST /api/v1/enrich/{id}` instead
