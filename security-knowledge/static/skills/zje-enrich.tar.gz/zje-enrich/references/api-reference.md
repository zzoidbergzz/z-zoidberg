# z.je API Quick Reference

Base: `https://z.je` | Auth: `X-API-Key` header | Docs: `/docs` | ReDoc: `/redoc`

## Authentication

```
POST /api/v1/auth/token          # Exchange API key for JWT: {"api_key": "..."}
POST /api/v1/auth/register       # New user: {email, password, full_name, business_sector}
POST /api/v1/auth/login          # Session cookie: {email, password}
GET  /api/v1/auth/me             # Current user profile
```

## Full Endpoint Map (80+)

### Auth & Keys
- `POST   /api/v1/auth/token` — API key → JWT
- `POST   /api/v1/auth/register` — Register user
- `GET    /api/v1/auth/me` — Profile
- `PATCH  /api/v1/auth/me` — Update profile
- `POST   /api/v1/auth/login` — Session login
- `POST   /api/v1/auth/logout` — Clear session
- `POST   /api/v1/auth/change-password`
- `GET    /api/v1/auth/provider-keys` — List BYOK keys
- `GET    /api/v1/auth/provider-keys/supported`
- `PUT    /api/v1/auth/provider-keys/{provider}` — Store BYOK key
- `DELETE /api/v1/auth/provider-keys/{provider}` — Remove BYOK key
- `GET    /api/v1/auth/api-keys` — List API keys
- `POST   /api/v1/auth/api-keys` — Create API key
- `POST   /api/v1/auth/api-keys/{id}/rotate`
- `DELETE /api/v1/auth/api-keys/{id}` — Revoke

### Entities
- `GET    /api/v1/entities/` — List (kind, limit≤200, offset)
- `POST   /api/v1/entities/` — Create {name, kind}
- `GET    /api/v1/entities/{id}` — Get with details
- `GET    /api/v1/entities/{id}/relationships` — Graph edges (limit≤500)

### Claims
- `GET    /api/v1/claims/` — List (limit≤200, offset)
- `POST   /api/v1/claims/` — Create {statement, claim_type, confidence, subject, predicate, object}
- `GET    /api/v1/claims/entity/{entity_id}` — Claims for entity
- `GET    /api/v1/claims/tor-screenshot/{filename}`
- `GET    /api/v1/claims/tor-artifact/{filename}`
- `GET    /api/v1/claims/onion/context?url=`

### Evidence
- `GET    /api/v1/evidence/` — List (limit≤200)
- `POST   /api/v1/evidence/` — Create {title, content, source_url, entity_id, claim_id, confidence}
- `GET    /api/v1/evidence/entity/{entity_id}` — Evidence for entity

### Search
- `GET    /api/v1/search/?q=&limit=100&corpus=` — Full-text search
- `POST   /api/v1/search/semantic` — {query, limit, kind} — vector search

### Enrichment
- `POST   /api/v1/enrich/{entity_id}` — Enrich existing entity
- `GET    /api/v1/enrich/{kind}/{value}/stream` — SSE enrichment (providers param)
- `POST   /api/v1/enrich/{kind}/{value}/refresh` — Force refresh

### EUVD
- `GET    /api/v1/euvd/search?q=&vendor=&product=&min_score=&max_score=&min_epss=&assigner=`

### Ingest
- `POST   /api/v1/ingest/` — {source_url, source_type, priority}
- `GET    /api/v1/ingest/jobs` — Job status

### MCP (60 tools)
- `GET    /api/v1/mcp/tools` — List all tools
- `POST   /api/v1/mcp/call` — {tool, args} — Execute tool

### Graph & Export
- `GET    /api/v1/graph/` — vis-network JSON
- `GET    /api/v1/stix/bundle` — STIX 2.1 export

### TAXII 2.1
- `GET    /taxii2/`
- `GET    /taxii2/collections/`
- `GET    /taxii2/collections/{id}/objects/`

### Webhooks
- `GET    /api/v1/webhooks/`
- `POST   /api/v1/webhooks/` — {url, event_types, secret}

### IOCs & Watchlists
- `GET    /api/v1/iocs/watches`
- `POST   /api/v1/iocs/watches` — {ioc_value, ioc_kind, mode, watchlist_id}
- `PATCH  /api/v1/iocs/watches/{id}`
- `DELETE /api/v1/iocs/watches/{id}`
- `GET    /api/v1/iocs/watches/{id}/sightings`

### Detections
- `GET    /api/v1/detections/`
- `POST   /api/v1/detections/` — {name, rule_type, rule_yaml, description, tags, severity}

### Digests
- `GET    /api/v1/digests/`
- `POST   /api/v1/digests/` — {name, frequency, channels, filters}

### Sources & Feeds
- `GET    /api/v1/sources/`
- `GET    /api/v1/sources/status`

### Audit
- `GET    /api/v1/audit/` — Audit log

### Admin
- `GET    /api/v1/admin/users`
- `POST   /api/v1/admin/users/{id}/approve`
- `POST   /api/v1/admin/users/{id}/tenant`
- `POST   /api/v1/admin/users/{id}/reset-password`
- `GET    /api/v1/admin/tenants`
- `POST   /api/v1/admin/tenants`
- `GET    /api/v1/admin/invites`
- `POST   /api/v1/admin/invites`
- `DELETE /api/v1/admin/invites/{id}`
- `GET    /api/v1/admin/stats`
- `POST   /api/v1/admin/sources/{id}/toggle`
- `GET    /api/v1/admin/watchlist-settings`
- `PUT    /api/v1/admin/watchlist-settings`
- `GET    /api/v1/admin/settings/watchlist`
- `PUT    /api/v1/admin/settings/watchlist`
- `POST   /api/v1/admin/watchlists`
- `GET    /api/v1/admin/settings/user-agent`
- `POST   /api/v1/admin/settings/user-agent`

### Sectors
- Sectors endpoints for ISAC/sector-based intelligence sharing

### Health & Metrics
- `GET    /health`
- `GET    /health/db`
- `GET    /metrics` — Prometheus

## Response Formats

### EntityOut
```json
{"id": "uuid", "canonical_name": "string", "kind": "EntityKind",
 "tenant_id": "uuid", "mitre_attack_id": "string|null",
 "external_refs": [], "created_at": "iso", "updated_at": "iso"}
```

### ClaimOut
```json
{"id": "uuid", "statement": "string", "claim_type": "string",
 "confidence": 0.0-1.0, "tenant_id": "uuid", "entity_id": "uuid", "source_url": "string|null"}
```

### EvidenceOut
```json
{"id": "uuid", "title": "string", "content": "string", "source_url": "string",
 "text_snippet": "string", "confidence": 0.0-1.0, "tenant_id": "uuid", "created_at": "iso"}
```

### SearchResult
```json
{"kind": "string", "id": "uuid", "name": "string", "score": 0.0,
 "description": "string", "tags": [], "confidence": 0.0, "cvss": 0.0,
 "severity": "string", "nvd_link": "string", "mitre_link": "string", "detail_url": "string"}
```

### RelationshipEdge
```json
{"id": "uuid", "kind": "string", "direction": "inbound|outbound",
 "confidence": 0.0, "peer": {"id": "uuid", "canonical_name": "string", "kind": "EntityKind"}}
```

### EUVDSearchHit
```json
{"id": "uuid", "euvd_id": "string", "title": "string", "summary": "string",
 "published_at": "iso", "modified_at": "iso", "cvss_score": 0.0,
 "cvss_version": "string", "cvss_vector": "string", "epss": 0.0,
 "aliases": [], "vendors": []}
```
