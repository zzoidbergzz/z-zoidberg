# z.je Enrichment Skill — Install Guide

## Quick Install (OpenClaw)

```bash
# Option 1: From ClawHub
openclaw skill install zje-enrich

# Option 2: Manual
mkdir -p ~/.openclaw/skills/zje-enrich
cp -r skills/zje-enrich/* ~/.openclaw/skills/zje-enrich/
```

## Configuration

Set environment variables or add to your OpenClaw config:

```bash
export ZJE_API_URL=https://z.je
export ZJE_API_KEY=your-api-key-here
```

Get your API key at [z.je/settings](https://z.je/settings) → API Keys → Create Key.

## BYOK Provider Keys

After installing, register your provider API keys:

```bash
# Using the client
python ~/.openclaw/skills/zje-enrich/scripts/zje_client.py set-key virustotal YOUR_VT_KEY
python ~/.openclaw/skills/zje-enrich/scripts/zje_client.py set-key shodan YOUR_SHODAN_KEY

# Or via API
curl -s -H "X-API-Key: $ZJE_API_KEY" -X PUT https://z.je/api/v1/auth/provider-keys/virustotal \
  -H "Content-Type: application/json" -d '{"api_key": "YOUR_VT_KEY"}'
```

Supported BYOK providers: virustotal, shodan, crowdstrike, greynoise, ipinfo, abuseipdb, misp, opencti, recordedfuture, otx, malshare

## LLM Analysis Setup

The skill uses YOUR LLM (the agent running it) for analysis. No additional LLM keys needed — the agent IS the LLM.

If using z.je's built-in `ask_question` MCP tool with Anthropic BYOK:
```bash
curl -s -H "X-API-Key: $ZJE_API_KEY" -X PUT https://z.je/api/v1/auth/provider-keys/anthropic \
  -H "Content-Type: application/json" -d '{"api_key": "YOUR_ANTHROPIC_KEY"}'
```

## Verify Installation

```bash
python ~/.openclaw/skills/zje-enrich/scripts/zje_client.py search "APT29"
```

## For z.je Self-Hosted

If running your own z.je instance, point to your server:
```bash
export ZJE_API_URL=https://your-instance.example.com
```
