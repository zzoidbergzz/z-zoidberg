# z.je Enrichment — Analyst Prompts v1.0
# Version: 1.0.0
# Last updated: 2026-05-10
# Changelog: v1.0 — Initial version

## SOC Analyst Review (simulated)

### What SOC analysts need from an enrichment skill:
1. **Speed** — IOC triage must be fast. Bulk lookup + auto-enrichment is critical.
2. **Verdict clarity** — Is this malicious, suspicious, or benign? No hedging.
3. **Context depth** — Not just "8.8.8.8 is Google" but "8.8.8.8 is Google DNS, commonly abused for DNS tunneling, seen in APT29 C2 per report X"
4. **Pivot points** — What else is on this IP/subnet/cert? What domains resolve here?
5. **False positive rate** — LLM hallucinations are dangerous in SOC. Hard cap at 0.5 confidence is essential.
6. **Integration** — Must feed into SIEM/SOAR. STIX export, webhook alerts.
7. **Watchlists** — Track IOCs over time. Get notified on sightings.

### SOC Analyst Assessment:
- ✅ IOC auto-detection + lookup — good
- ✅ Provider enrichment (VT, Shodan, GreyNoise) — exactly what SOC needs
- ✅ SSE streaming for real-time triage — great for dashboards
- ✅ Watchlist + sighting tracking — critical for monitoring
- ✅ STIX/TAXII export — feeds into TIPs
- ✅ LLM confidence cap at 0.5 — prevents false alarm escalation
- ⚠️ Need: Priority scoring (critical/high/medium/low) not just confidence
- ⚠️ Need: SIEM-friendly timestamp formats (epoch ms)
- ⚠️ Need: CQL hunt suggestions for detection engineering

## Threat Intelligence Analyst Review (simulated)

### What TI analysts need:
1. **Attribution confidence** — Who is behind this? With what evidence?
2. **Campaign tracking** — Link incidents to campaigns, track evolution
3. **Infrastructure mapping** — Graph of related infrastructure over time
4. **TTP extraction** — What MITRE ATT&CK techniques are in play?
5. **Source provenance** — Where did each data point come from? Can I trace it?
6. **LLM augmentation** — Use LLM for hypothesis generation, NOT for evidence
7. **Temporal analysis** — When did this infrastructure appear? Evolution over time?

### TI Analyst Assessment:
- ✅ Entity-claim-evidence model — perfect for structured TI
- ✅ Relationship graph — critical for infrastructure mapping
- ✅ MITRE ATT&CK integration (30+ tools) — best-in-class
- ✅ LLM analysis as hypothesis, not evidence — exactly right
- ✅ Provenance tracking via source_url — essential for TI reports
- ⚠️ Need: Campaign entity kind + campaign linking
- ⚠️ Need: Temporal search (entities modified/created since date)
- ⚠️ Need: Diff tracking on enrichment refresh

## Unified Prompt Template v1.0

### Prompt: IOC Triage
```
Given the IOC {ioc_value}, perform the following:

1. CLASSIFY: Determine the IOC type (ip, domain, hash, url, email)
2. SEARCH: Query z.je for existing intelligence on this IOC
3. ENRICH: Run provider enrichment (VT, Shodan, GreyNoise, AbuseIPDB)
4. CONTEXT: Retrieve related entities and relationships
5. ANALYZE: Based on gathered data, assess:
   a. Maliciousness verdict (malicious/suspicious/benign/unknown)
   b. Associated threat actors (with confidence ≤ 0.5 if LLM-derived)
   c. Related infrastructure (with evidence)
   d. MITRE ATT&CK TTPs observed
   e. Recommended detection rules (SIGMA/YARA/CQL)
6. POST: Submit findings to z.je with proper provenance tagging
7. VERIFY: Cross-check LLM findings against available sources

Output format: Structured findings with confidence scores and source attribution.
```

### Prompt: Threat Actor Profile
```
Build a threat actor profile for {actor_name}:

1. SEARCH: Query z.je for existing actor intelligence
2. MITRE: Get techniques, software, campaigns for this actor
3. ENRICH: Look up any known IOCs associated with the actor
4. ANALYZE: Produce structured profile:
   a. Aliases and naming history (from MITRE + z.je)
   b. Target sectors and geographies
   c. TTPs with MITRE mapping
   d. Known tools and malware families
   e. Infrastructure patterns
   f. Campaign timeline
5. POST: Create/update entity, add claims for each finding
6. LINK: Create relationships to related entities (malware, victims, infrastructure)

All LLM-derived claims: claim_type=llm_analysis, confidence≤0.5, evidence with model tag.
```

### Prompt: Vulnerability Impact Assessment
```
Assess the impact of {cve_id}:

1. LOOKUP: Get CVE details from NVD via lookup_cve
2. EUVD: Check EU vulnerability database for EU-specific data
3. EXPLOIT: Search for known exploits via exploit_search
4. CONTEXT: Find entities in z.je referencing this CVE
5. ANALYZE:
   a. CVSS score and vector breakdown
   b. EPSS probability (if available)
   c. Known exploitation status (CISA KEV, EUVD exploited)
   d. Affected products and versions
   e. Available mitigations (MITRE mitigations)
   f. Detection opportunities (Sigma/YARA rules)
6. POST: Create claims for each analysis point
7. LINK: Connect to affected products, threat actors, detection rules

LLM analysis capped at confidence 0.5. Verify CVSS/EPSS via NVD enrichment.
```

### Prompt: Infrastructure Correlation
```
Analyze infrastructure overlap between entities:

Input: List of entity names or IOCs

1. ENRICH: Run full enrichment on each entity
2. GRAPH: Build relationship graph (depth=2)
3. ANALYZE:
   a. Shared hosting (same IP, ASN, registrar)
   b. Certificate overlap (shared SSL certs, CA)
   c. Temporal correlation (registered/first_seen within window)
   d. DNS patterns (same nameservers, MX records)
   e. WHOIS data overlap (registrant, org)
4. HYPOTHESIZE: Generate infrastructure cluster hypotheses
5. POST: Create llm_analysis claims for each hypothesis
6. VERIFY: Check if any hypothesis is confirmed by provider data

All hypotheses are llm_analysis with confidence≤0.4.
Flag unverifiable correlations with [UNVERIFIED].
```

### Prompt: Detection Engineering
```
Generate detection rules for {threat_actor or technique}:

1. CONTEXT: Gather TTPs from MITRE ATT&CK
2. KNOWLEDGE: Search z.je for existing detection rules
3. ANALYZE: For each TTP:
   a. Map to log sources (Windows Event, Sysmon, Network, etc.)
   b. Identify key indicators and patterns
   c. Generate detection logic (Sigma for EDR, CQL for cloud)
4. VALIDATE: Cross-reference against known false positives
5. POST: Create detection rule entities with rule_yaml
6. LINK: Connect rules to the techniques they detect

Detection rules are high-value. If LLM-generated, mark as llm_analysis.
If validated against known threat data, can be upgraded to enrichment.
```

## Scoring Rubric for LLM Findings

| Factor | Adjustment |
|--------|-----------|
| LLM source (any) | × 0.5 |
| Stacked LLM (LLM citing LLM) | × 0.25 |
| Cross-referenced with MITRE | +0.1 (cap 0.5) |
| Partially verified by provider | upgrade to `enrichment` |
| Fully verified by provider | upgrade to `enrichment`, confidence ≤ 0.9 |
| OSINT source found | upgrade to `osint`, confidence ≤ 0.8 |
| No verification possible | stays `llm_analysis`, ≤ 0.4 |
| Specific IOC produced by LLM | × 0.2 until verified |
| Generic analytical observation | × 0.5 (standard) |

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2026-05-10 | Initial version — 5 prompt templates, SOC + TI analyst review, scoring rubric |
